const Student = require('./Student');
const MainInfo = require('./MainInfo');
const Banned = require('./Banned');
const Otp = require('./Otp');

module.exports = {
  Student,
  MainInfo,
  Banned,
  Otp
};